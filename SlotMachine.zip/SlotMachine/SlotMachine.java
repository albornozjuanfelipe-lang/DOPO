import java.util.ArrayList;
import java.util.HashSet;
import javax.swing.JOptionPane;

public class SlotMachine
{
    private ArrayList<String> symbols;
    private ArrayList<Wheel> wheels;
    private boolean visible;
    private boolean lastOk;

    public SlotMachine()
    {
        symbols = new ArrayList<String>();
        wheels = new ArrayList<Wheel>();
        visible = false;
        lastOk = true;
    }

    public void addWheel(int pos)
    {
        int p = clamp(pos, wheels.size() + 1);
        Wheel wheel = new Wheel(symbols);
        wheels.add(p - 1, wheel);
        relayout();
        if (visible) {
            wheel.makeVisible();
        }
        succeed();
    }

    public void delWheel(int pos)
    {
        if (!validWheel(pos)) {
            fail("No existe una rueda en la posición " + pos + ".");
            return;
        }
        Wheel wheel = wheels.remove(pos - 1);
        wheel.makeInvisible();
        relayout();
        succeed();
    }

    public void addSymbol(int pos, String color)
    {
        int p = clamp(pos, symbols.size() + 1);
        symbols.add(p - 1, color);
        succeed();
    }

    public void delSymbol(String symbol)
    {
        boolean removed = symbols.remove(symbol);
        if (!removed) {
            fail("El símbolo " + symbol + " no existe en la máquina.");
            return;
        }
        succeed();
    }

    public void placeSymbol(int wheel, String symbol)
    {
        if (!validWheel(wheel)) {
            fail("No existe una rueda en la posición " + wheel + ".");
            return;
        }
        boolean placed = wheels.get(wheel - 1).place(symbol);
        if (!placed) {
            fail("El símbolo " + symbol + " no existe en la máquina.");
            return;
        }
        succeed();
    }

    public void spin(int wheel)
    {
        if (!validWheel(wheel)) {
            fail("No existe una rueda en la posición " + wheel + ".");
            return;
        }
        wheels.get(wheel - 1).spin(randomSteps());
        succeed();
    }

    public String[] symbols()
    {
        return symbols.toArray(new String[0]);
    }

    public int distinctSymbols()
    {
        return new HashSet<String>(configurationList()).size();
    }

    public String[] configuration()
    {
        return configurationList().toArray(new String[0]);
    }

    public boolean isJackpot()
    {
        return !wheels.isEmpty() && distinctSymbols() == 1;
    }

    public void makeVisible()
    {
        visible = true;
        for (Wheel wheel : wheels) {
            wheel.makeVisible();
        }
    }

    public void makeInvisible()
    {
        visible = false;
        for (Wheel wheel : wheels) {
            wheel.makeInvisible();
        }
    }

    public void exit()
    {
        makeInvisible();
        wheels.clear();
        symbols.clear();
    }

    public boolean ok()
    {
        return lastOk;
    }

    private boolean validWheel(int wheel)
    {
        return wheel >= 1 && wheel <= wheels.size();
    }
    
    private int clamp(int pos, int max)
    {
        if (pos < 1) {
            return 1;
        }
        if (pos > max) {
            return max;
        }
        return pos;
    }

    private int randomSteps()
    {
        return (int) (Math.random() * 100) + 1;
    }

    private ArrayList<String> configurationList()
    {
        ArrayList<String> config = new ArrayList<String>();
        for (Wheel wheel : wheels) {
            config.add(wheel.currentSymbol());
        }
        return config;
    }

    private void relayout()
    {
        for (int i = 0; i < wheels.size(); i++) {
            wheels.get(i).placeAt(i);
        }
    }

    private void succeed()
    {
        lastOk = true;
    }

    private void fail(String message)
    {
        lastOk = false;
        if (visible) {
            JOptionPane.showMessageDialog(null, message);
        }
    }
}
