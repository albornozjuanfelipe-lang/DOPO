import java.util.ArrayList;

public class Wheel
{
    private static final int BASE_X = 20;
    private static final int STEP_X = 60;
    private static final int DIAMETER = 40;

    private ArrayList<String> symbols;
    private int currentIndex;
    private Circle window;
    private int slot;
    private int xPos;

    public Wheel(ArrayList<String> sharedSymbols)
    {
        symbols = sharedSymbols;
        currentIndex = 0;
        slot = 0;
        xPos = BASE_X;
        window = new Circle();
        window.changeSize(DIAMETER);
        updateColor();
    }

    public void spin(int steps)
    {
        if (symbols.isEmpty()) {
            return;
        }
        int size = symbols.size();
        currentIndex = ((currentIndex + steps) % size + size) % size;
        updateColor();
    }

    public boolean place(String symbol)
    {
        int index = symbols.indexOf(symbol);
        if (index == -1) {
            return false;
        }
        currentIndex = index;
        updateColor();
        return true;
    }

    public String currentSymbol()
    {
        if (symbols.isEmpty()) {
            return null;
        }
        return symbols.get(currentIndex);
    }

    public void placeAt(int newSlot)
    {
        slot = newSlot;
        int targetX = BASE_X + slot * STEP_X;
        window.moveHorizontal(targetX - xPos);
        xPos = targetX;
    }

    public void makeVisible()
    {
        window.makeVisible();
    }

    public void makeInvisible()
    {
        window.makeInvisible();
    }

    private void updateColor()
    {
        String symbol = currentSymbol();
        window.changeColor(symbol == null ? "black" : symbol);
    }
}
